#!/bin/bash
# Cursor Conversion Script for Fantasy Railroad (ulfantrr)
#This file must be located in the cursorPNG directory to work.
#This script converts Windows cursors into X11 format.

#Part 1 _ create the cursor configuration files from extracted PNG frames

#echo -e 32 0 0 norma1_0.png 120"\n"32 0 0 normal_1.png 120 > normal.cursor
echo -e 32 0 0 help_0.png 120"\n"32 0 0 help_1.png 120 > help.cursor
echo -e 32 0 0 busy_0.png 120"\n"32 0 0 busy_1.png 120"\n"32 0 0 busy_2.png 120"\n"32 0 0 busy_3.png 120"\n"32 0 0 busy_4.png 120"\n"32 0 0 busy_5.png 120"\n"32 0 0 busy_6.png 120"\n"32 0 0 busy_7.png 120"\n"32 0 0 busy_8.png 120"\n"32 0 0 busy_9.png 120"\n"32 0 0 busy_10.png 120"\n"32 0 0 busy_11.png 120"\n"32 0 0 busy_12.png 120"\n"32 0 0 busy_13.png 120"\n"32 0 0 busy_14.png 120"\n"32 0 0 busy_15.png 120"\n"32 0 0 busy_16.png 120"\n"32 0 0 busy_17.png 120"\n"32 0 0 busy_18.png 120"\n"32 0 0 busy_19.png 120 > busy.cursor
echo -e 32 15 15 cross_0.png 120"\n"32 15 15 cross_1.png 120 > cross.cursor
echo -e 32 15 15 diagonal1_0.png 120"\n"32 15 15 diagonal1_1.png 120 > diagonal1.cursor
echo -e 32 15 15 diagonal2_0.png 120"\n"32 15 15 diagonal2_1.png 120 > diagonal2.cursor
echo -e 32 15 15 ns_0.png 120"\n"32 15 15 ns_1.png 120 > ns.cursor
echo -e 32 15 15 we_0.png 120"\n"32 15 15 we_1.png 120 > we.cursor
echo -e 32 15 15 no_0.png 120"\n"32 15 15 no_1.png 120 > no.cursor
echo -e 32 15 15 move_0.png 120"\n"32 15 15 move_1.png 120 > move.cursor
echo -e 32 5 10 ibeam_0.png 120"\n"32 5 10 cross_1.png 120 > ibeam.cursor
echo -e 32 5 0 up_0.png 120"\n"32 5 0 up_1.png 120 > up.cursor
echo -e 32 0 0 pen_0.png 120"\n"32 0 0 pen_1.png 120 > pen.cursor
echo -e 32 0 0 working_0.png 120"\n"32 0 0 working_1.png 120"\n"32 0 0 working_2.png 120"\n"32 0 0 working_3.png 120"\n"32 0 0 working_4.png 120"\n"32 0 0 working_5.png 120"\n"32 0 0 working_6.png 120"\n"32 0 0 working_7.png 120"\n"32 0 0 working_8.png 120"\n"32 0 0 working_9.png 120"\n"32 0 0 working_10.png 120"\n" > working.cursor
echo -e 32 0 0 link_0.png 120"\n"32 0 0 link_1.png 120"\n"32 0 0 link_2.png 120"\n"32 0 0 link_3.png 120"\n"32 0 0 link_4.png 120"\n"32 0 0 link_5.png 120"\n"32 0 0 link_6.png 120"\n"32 0 0 link_7.png 120"\n"32 0 0 link_8.png 120"\n"32 0 0 link_9.png 120"\n"32 0 0 link_10.png 120"\n"32 0 0 link_11.png 120"\n"32 0 0 link_12.png 120"\n"32 0 0 link_13.png 120"\n"32 0 0 link_14.png 120"\n"32 0 0 link_15.png 120"\n"32 0 0 link_16.png 120"\n"32 0 0 link_17.png 120"\n"32 0 0 link_18.png 120"\n"32 0 0 link_19.png 120"\n"32 0 0 link_20.png 120"\n" > link.cursor

#Part 2 _ convert cursor configuration files into actual X11 cursors
xcursorgen normal.cursor x11/left_ptr
xcursorgen normal.cursor x11/arrow
xcursorgen help.cursor x11/gumby
xcursorgen help.cursor x11/question_arrow
xcursorgen working.cursor x11/left_ptr_watch
xcursorgen busy.cursor x11/watch
xcursorgen pen.cursor x11/pencil
xcursorgen ibeam.cursor x11/xterm
xcursorgen diagonal1.cursor x11/top_left_corner
xcursorgen diagonal1.cursor x11/bottom_right_corner
xcursorgen diagonal2.cursor x11/top_right_corner
xcursorgen diagonal2.cursor x11/bottom_left_corner
xcursorgen we.cursor x11/left_side
xcursorgen we.cursor x11/right_side
xcursorgen we.cursor x11/h_double_arrow
xcursorgen ns.cursor x11/top_side
xcursorgen ns.cursor x11/bottom_side
xcursorgen ns.cursor x11/v_double_arrow
xcursorgen move.cursor x11/fleur
xcursorgen move.cursor x11/grabbing
xcursorgen move.cursor x11/size_all
xcursorgen no.cursor x11/crossed_circle
xcursorgen no.cursor x11/no_drop
xcursorgen up.cursor x11/center_ptr
xcursorgen link.cursor x11/link

exit

